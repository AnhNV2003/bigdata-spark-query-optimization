# Trajectory Profile Recommendations

- Profile window: `2025-01-01 00:00:00` to `2026-01-01 00:00:00`
- Rows profiled: `48722573`
- Partition candidate: `trip_year`, `trip_month` because trajectory queries are time-window driven.
- Bucketing candidate: `origin_zone_id` with `16` buckets because zone lookup/join queries target spatial keys.
- Join-skew candidate: `origin_zone_id` because pickup zones naturally concentrate around airports and dense business areas.
- Top origin zone: `237` with `2125560` trips (4.3626% of profiled rows).
- Top route: `237->236` with `302261` trips (0.6204% of profiled rows).

Use the exported CSV files to justify the benchmark layout choices before running format, partition, bucketing, and join-skew experiments.
